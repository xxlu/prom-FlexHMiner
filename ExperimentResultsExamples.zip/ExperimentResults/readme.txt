Due to limited space on Github and the signed NDA with the hospital, this folder only contains a subset of the results, shown as examples.

